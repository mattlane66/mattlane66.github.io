# Feature: [name]

**Status:** TEMPLATE ONLY — not a selected feature or permission to build.
**Product intent:** Link to `../../PRODUCT.md` and any accepted framing/shaping documents.
**Human-selected direction/date:** Not yet selected.

## Problem and intended outcome

- **Who and in what situation:**
- **What they struggle to do today:**
- **Outcome we want:**
- **Evidence or assumptions behind this:**

## Requirements and selected approach

- **What must be true regardless of solution:**
- **Options considered and why this approach was chosen:**
- **Selected behavior:**
- **Accepted Appetite (effort worth spending) and cut line:**
- **Non-goals or deferred scope:**

## Smallest complete slice

- **Human-selected user journey from entry to result:**
- **What is included:**
- **What is not included:**
- **Relevant existing behavior that must keep working:**
- **Main uncertainties and integration boundaries:**

## Expected behavior

- **Main path:**
- **Important alternatives, failures, and recovery:**
- **Saved data / persistence, if relevant:**
- **Access and permissions, if relevant:**
- **Accessibility and quality floor:**

## Verification and human acceptance

- **What the agent must test and directly observe:**
- **How the product owner can personally demo this:**
- **What would count as acceptable experience:**
- **What real-world result could be observed after release (may remain pending):**
- **Mocks, assumptions, and known unverified parts:**

## Execution boundaries

- **Worth in human review/attention:**
- **Needed by (only if timing matters):**
- **Protect (MUSTs and quality floor):**
- **Cut first (NICEs):**
- **Stop and return to shaping if:**

## Human approvals before implementation

- [ ] Intended problem / requirements and relevant constraints accepted
- [ ] Proposed solution and effort/cut line accepted
- [ ] Active end-to-end slice and its behavior accepted
- [ ] Execution boundaries accepted; implementation explicitly authorized

> This brief owns intended behavior and acceptance criteria, **not daily progress**. Track implemented, verified, accepted, and effect-observed status with evidence in `../CURRENT.md`. These approval boxes are not a substitute for an explicit human decision.
