# Feature: [name]

**Status** — Template only. A feature brief starts Working until approval is recorded in [CURRENT.md](../CURRENT.md).
**Product intent:** Link to `../../PRODUCT.md` and any accepted framing/shaping documents.
**Revision and decisions** — Link to the revision-specific approval and authorization records in [CURRENT.md](../CURRENT.md) when available.
**Selected direction:** Not yet selected; link to the selection decision in `../CURRENT.md` when established.

_Use only sections relevant to this slice. Omit or mark irrelevant prompts Not applicable; do not manufacture requirements, budgets, evidence, or approvals. This brief specifies intended behavior and boundaries. Dated approval and authorization records live only in `../CURRENT.md`._

## Problem and intended outcome

- **Who and in what situation:**
- **What they struggle to do today:**
- **Outcome we want:**
- **Evidence or assumptions behind this:**

## Requirements and selected approach

- **What must be true regardless of solution:**
- **Options considered and why this approach was chosen:**
- **Selected behavior:**
- **Accepted Appetite (effort worth spending) and cut line:**
- **Non-goals or deferred scope:**

## Two-way fit check (keep proportional)

- **R × S — coverage:** For each important requirement, how does the selected approach satisfy it? What is missing or unproven?
- **S × R — necessity:** For each consequential part of the approach, which requirement or outcome does it serve? Could it be removed or simplified?
- **Tradeoffs and risk:** Which alternative was rejected, why, and what assumption could change that choice?

_Use a short explanation for an obvious change; a simple table or the project's accepted Planning Skills artifacts for complex decisions. Reference accepted artifacts rather than creating a conflicting second source of truth._

## Smallest complete slice

- **Product-owner-selected user journey from entry to result:**
- **What is included:**
- **What is not included:**
- **Relevant existing behavior that must keep working:**
- **Main uncertainties and integration boundaries:**

## Expected behavior

- **Main path:**
- **Important alternatives, failures, and recovery:**
- **Saved data / persistence, if relevant:**
- **Access and permissions, if relevant:**
- **Feature-specific data, network, and execution limits, if relevant** — Record any applicable limits on storage, data movement, remote calls, or external services.
- **Accessibility and quality floor:**

## Verification and result acceptance

- **Representative user tasks and experience criteria:**
- **What the agent must test and directly observe (including failures/recovery):**
- **How the product owner can personally demo this:**
- **What would count as acceptable experience:**
- **What real-world result could be observed after release (may remain pending):**
- **Mocks, assumptions, and known unverified parts:**

## Execution boundaries

- **Worth in human review/attention:**
- **Machine/runtime limit (if material; e.g., agent time, tool calls, retries):**
- **Spend or operating-cost limit (if material):**
- **Needed by (only if timing matters):**
- **Protect (MUSTs and quality floor):**
- **Cut first (NICEs):**
- **Stop and return to shaping if:**
- **Main risk / independent review needed? If yes, review what and when:**

## Approval and authorization check (read from `../CURRENT.md`)

Before implementation, confirm that the dated **Brief approved** and **Build authorized** records cover the revision and scope to be built. Use the [revision comparison rules](../../AGENTS.md#authority-and-accepted-intent) when the brief changes. No approval is granted by filling this template.

> This brief owns intended behavior and acceptance criteria, **not approval state or daily progress**. `../CURRENT.md` is the one authoritative record for decisions, implementation status, tests, result acceptance, and effects in use.
