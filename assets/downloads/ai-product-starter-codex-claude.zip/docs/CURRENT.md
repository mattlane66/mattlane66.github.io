# Current project state

**Last updated:** Not yet established
**Current work:** New-project discovery; no implementation slice selected
**Active feature brief:** None
**Next authorized action:** Interview the product owner and draft product context for review. Do not begin implementation.

## What exists now

- Product implementation: Not yet inspected or created.
- Verified, demoable user experience: None verified.
- Relevant run/test/demo commands: Not yet discovered. Do not invent them.

## Status and evidence

| Item | Status | Direct evidence / limitation |
| --- | --- | --- |
| Product context | Working | `PRODUCT.md` contains placeholders, not an accepted product decision |
| Selected solution | Not selected | No human decision recorded |
| Active vertical slice | Not authorized | No accepted feature brief |
| Implementation | Not verified | No checks have been run |

## Progress toward the accepted outcome

- **Accepted outcome:** None yet; refer to `PRODUCT.md` once the human approves one.
- **Design fit:** Not yet evaluated against an accepted slice.
- **Observed implementation:** No complete user journey verified.
- **Human acceptance:** No experience has been accepted.
- **Effect in real use:** Unknown; no actual usage evidence recorded.
- **Most important gap or assumption to test next:** Establish what outcome is worth pursuing.

_Keep these distinct. A demo, passing test, human acceptance, and evidence that users benefited are different milestones._

## Open decisions or blockers

- Establish the problem, audience, desired outcome, boundaries, and what the effort is worth.
- Select an approach and one demoable slice before authorizing the build.

## Most recent completed work

_No verified work recorded yet._

## Next authorized move

- **Authorized next action:** Interview and draft; no code implementation approved.
- **Needed human decision:** Accept, revise, or reject the initial product framing.
- **Thread guidance:** Not yet needed. When routing matters, the agent should explain CONTINUE THIS THREAD, START A NEW THREAD, or STOP AND REASSESS in its response; this file records durable state, not a pile of reusable chat prompts.

_Record any explicit approval or change to authorization here; do not treat this status file as permission to broaden product scope._

> **Status rule:** Update this file after meaningful progress. State what actually ran and what was observed. Keep intent and acceptance criteria in `PRODUCT.md` and accepted feature briefs. When parallel agents work, reconcile changes instead of overwriting another workstream's status.
