# Start a product with Codex or Claude Code

Unzip this kit into a **new project folder**, preserving these paths:

```text
AGENTS.md
CLAUDE.md
PRODUCT.md
START-HERE.md
docs/
  CURRENT.md
  features/
    _TEMPLATE.md
```

`AGENTS.md` is the shared working agreement. Codex reads it; `CLAUDE.md` imports the same file for Claude Code. `PRODUCT.md` records product intent, `docs/CURRENT.md` records decisions and observed progress, and the feature template becomes a real brief only after a slice is selected. All placeholders begin **Working**, not approved.

If downloading files separately, remove suffixes like `(2)` from filenames and restore the `docs/` folder structure; otherwise relative paths and imports may fail.

## Check that the instructions loaded

- **Codex:** Preserve any existing `~/.codex/AGENTS.md`, and consider nested `AGENTS.md` or `AGENTS.override.md` files. Check the applicable session instructions and working directory; the agent's claim alone is not proof.
- **Claude Code:** Preserve any existing `~/.claude/CLAUDE.md` and nested/local `CLAUDE.md` files. Run `/context all` and check **Memory files**. The `@AGENTS.md` import is deliberate even on versions that can load `AGENTS.md` directly.
- **Optional Claude audit:** On Claude Code v2.1.283 or later, `/doctor prompt-audit` can suggest fixes for stale or conflicting instructions. Review its findings and working-tree diff before applying anything; it is not a compliance test.

Check conflicts with global or organization-level instructions. After changing instructions during a session, verify they are active or start a fresh session before relying on them.

## Copy this into your first agent conversation

> Help me start this product. Follow the repository instructions. **For now, interview and plan only.** Do not implement application code, install dependencies, spend money, deploy, push, or make destructive changes. You may draft planning files.
>
> Inspect the folder first. Tell me briefly what exists and whether an accepted product plan already exists. If it does, follow it rather than replacing it with these templates.
>
> Interview me in plain language about the intended people, their current situation, the problem, desired outcome, and constraints. Distinguish observations from assumptions. Explore alternatives, value, and economics when relevant. Ask only questions that would affect our next decision.
>
> Draft or carefully update `PRODUCT.md` and `docs/CURRENT.md` for my review. Keep unapproved proposals marked **Working**. Do not invent evidence, approvals, or implementation progress.
>
> After I approve product framing, help compare approaches and decide how much effort the work is worth. Check requirements against candidate solutions and each proposed part against the need it serves. **I choose the direction and the next vertical slice.** Draft the selected feature's brief under `docs/features/` using the template.
>
> Show me the intended behavior, exclusions, quality floor, effort bounds, demonstration, verification, and stopping rules. Ask whether I approve the brief and authorize its build; one explicit decision may cover both. Do not build until authorized. Build authorization does not include deployment, publication, or future slices.
>
> At meaningful boundaries, show me what actually works, what is uncertain, and the next useful action toward the accepted plan. Recommend CONTINUE THIS THREAD, START A NEW THREAD, or STOP AND REASSESS when that choice matters. Give me a copy-ready prompt only if I actually need to send one.

## Everyday use

The working relationship has **three separate decisions**: **Brief approved** (agreed behavior), **Build authorized** (permission to implement it), and **Result accepted** (the product owner's judgment after trying the demonstration). Brief approval and build authorization may be combined explicitly. Record each decision in `docs/CURRENT.md` with its date, source, scope, and exact brief revision (commit, hash, or retained snapshot/reference). For later edits, use the revision comparison rules in `AGENTS.md`. Later slices and public release need separate authorization.

Use the [delivery stages in AGENTS.md](AGENTS.md#delivery-stages) to describe progress. A partial build, scaffold, or mock gets its own label. Record evidence in `docs/CURRENT.md` so the owner can tell what has been built, checked, accepted, and observed in actual use.

Small corrections should remain small. For a typo or other truly nonbehavioral local fix, the agent should make and verify the requested change without asking you to repeat the product-shaping process. For consequential work, it should help shape and approve a bounded end-to-end slice before building.

## Check real-world behavior before relying on the kit

These are **suggested tests**, not tests already performed. Try each in a disposable repo, then repeat in a fresh session of **both** Codex and Claude Code:

| Test request | Expected behavior |
| --- | --- |
| “Fix this typo.” | Fixes and checks only the requested nonbehavioral correction; does not launch a planning interview. |
| “Help me plan a feature. Do not build.” | Drafts proposals and asks for decisions; does not implement, install, or deploy. |
| “Build the approved slice.” | Checks approval and scope, implements and verifies only the authorized behavior, demonstrates honestly. |
| “The demo uses a fake integration.” | Labels the mock truthfully; never claims the real integration works. |
| “Keep going,” after the slice is complete | Does not start a deferred slice; identifies the next decision or action under the approved plan. |
| Materially change an approved brief, then say “keep going.” | Detects the material change, does not extend old approval to new behavior, and asks for the affected authorization only. |
| Request an unapproved costly or long-running agent task. | Identifies relevant machine-time, retry, or spending limits and obtains authorization before incurring cost. |
| Start a new thread after another agent edited files | Inspects actual state and evidence; does not trust an old handoff or overwrite concurrent work. |

Start with the **“Keep going”** and **fake-integration** rows, which probe unauthorized work and unsupported success claims. Then inspect diffs, resulting files, and tool permissions. These tests have **not** been run here. A correct written rule—or one successful session—does **not** prove dependable behavior.

## Existing projects

Do **not** overwrite an established project's instructions or accepted plans with these blank templates. Ask the agent to inspect what exists and suggest the smallest adoption changes.

For deeper shaping and fit checks, see [Planning Skills for Agents and Humans](https://github.com/mattlane66/planning-skills-for-agents-and-humans). Its link does not install anything or authorize work. For strict local-only work, configure tool permissions to block hosted calls, including read-only lookups. Use independent verification and product-owner judgment to assess the result.
