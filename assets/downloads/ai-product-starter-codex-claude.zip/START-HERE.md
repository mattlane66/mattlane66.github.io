# Start a new product with Codex or Claude Code

This starter works in a new, empty project folder. Copy the files into the project root, preserving `docs/`.

- **Codex** reads `AGENTS.md`. If you already have a personal `~/.codex/AGENTS.md`, keep it. These short project instructions add project-specific rules rather than replacing your global agreement.
- **Claude Code** reads `CLAUDE.md`, whose single `@AGENTS.md` line imports the same project rules. Do not duplicate or maintain two different agreements. Recent Claude Code versions can read `AGENTS.md` directly, but the import also covers versions/settings that prefer `CLAUDE.md`.
- Check that the tool actually loaded the right project instructions. In Claude Code, `/context` can help. For Codex, ask which instruction files were automatically applied and verify where possible; the model's report is not conclusive proof.

These are the initial **working** files, not a preapproved product specification. `PRODUCT.md` and `docs/CURRENT.md` deliberately begin with honest unknowns. `docs/features/_TEMPLATE.md` is a template, **not** an active feature. Create a named feature brief only after a solution and slice are chosen.

## Paste this as your first message in the coding agent

> Help me start a new product in this repository. Follow the applicable project instructions. For now, **plan and interview only**—do not implement, install dependencies, spend money, deploy, push, or make destructive changes.
>
> Inspect this folder and tell me briefly what already exists. Then interview me in plain language about who the product is for, what people do today, what problem matters, what outcome I want, and the constraints or unknowns. Don't ask technical questions I don't need to decide, and don't invent evidence.
>
> Draft `PRODUCT.md` and an accurate initial `docs/CURRENT.md` for my review. Distinguish Working from Accepted and ask before replacing accepted product intent.
>
> Once I accept the product framing, help me explore reasonable approaches and decide how much effort the opportunity is worth. I choose the direction. Then propose the smallest complete end-to-end experience worth building. Only after I select it, draft `docs/features/<feature-name>.md` using the template, including behavior, exclusions, demonstration, verification, and stop conditions.
>
> **Show me the proposed brief and ask for approval before implementing anything.** Approval of a draft is not permission to publish, deploy, or start later slices. Keep all explanations clear and nontechnical.

## Normal work after kickoff

1. Approve the product intent, chosen solution, and the one active feature brief.
2. Authorize that slice. The agent implements, checks, and demonstrates it; you accept or request changes.
3. The agent updates `docs/CURRENT.md` with what was actually verified, what remains open, and the next authorized move.
4. Repeat with the next worthwhile slice. Use additional planning artifacts only when the uncertainty or complexity warrants them.

**If you're adding this to an existing product:** do not blindly replace its instructions, product records, or progress notes. Ask the agent to inspect the current repository first and propose a minimal, reviewable adoption plan.

### Planning method (optional)

[Planning Skills for Agents and Humans](https://github.com/mattlane66/planning-skills-for-agents-and-humans) provides framing, collaborative shaping, fit checks, breadboarding, and bounded implementation handoffs when useful. It is not required to complete a simple task.

### Boundary

Instruction files influence agent behavior; they do not replace tool permissions, access controls, independent verification, or your approval.
