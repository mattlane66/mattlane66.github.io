# Product context

**Status:** Working — not yet approved. Complete this with the product owner during the first interview; do not assume placeholders are requirements.

When the owner approves the framing, mark it Accepted and record the decision reference in `docs/CURRENT.md`. Approval of product intent does not itself authorize implementation or accept a delivered result.

## Who this is for

_Not established yet._

## Situation today

- **Trigger or context:** Not established.
- **What people do now (including workarounds or doing nothing):** Not established.
- **Where that approach falls short:** Not established.
- **Evidence versus assumptions:** No evidence recorded yet.

## Desired outcome

_What should become possible or better for these people? Not established yet._

## Evidence of demand and alternatives

- **What we have observed about the struggle (sources/dates, if any):** Not established.
- **Alternatives, workarounds, and choosing to do nothing:** Not established.
- **Value signals or willingness to pay (if commercially relevant):** Not established.
- **What evidence could change our judgment:** Not established.

## Why this is worth pursuing

- **Value to the intended users:** Not established.
- **Economics (if relevant):** Cost to create and operate, possible revenue/savings, distribution or reach, and important assumptions. Not established.
- **Why now rather than later or not at all:** Not established.

_For a personal, nonprofit, or exploratory project, mark commercial questions Not applicable instead of manufacturing a business case._

## Product boundaries

- **Must preserve or satisfy:** Not established.
- **Non-goals:** Not established.
- **Important constraints (time, cost, legal, operational, access):** Not established.
- **Data, network, and execution limits, if relevant** — Record applicable limits such as local-only work, restricted data movement, prohibited remote calls, or approved external services. Establish the actual limits with the owner.

## Core product concepts and journeys

_People, objects, actions, states, and relationships that should remain coherent across features. Not established._

## How we will judge success

- **What someone should be able to do or experience:** Not established.
- **Baseline or present result, if known:** Not established.
- **Quality floor and critical journeys to protect:** Not established.
- **What we could observe in actual use after delivery:** Not established.

_Do not invent targets or treat expected behavior, demonstrated behavior, and actual effects in use as the same evidence._

## Important unknowns and decisions

- Open: Which problem and outcome should become the accepted product boundary?
- Open: What evidence or direct observation could change that decision?

## Accepted direction

**None yet.** The product owner must explicitly approve material changes to this section and to accepted purpose, scope, or behavior.
