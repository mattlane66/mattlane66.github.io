# Product context

**Status:** Working — not yet approved. Complete this with the product owner during the first interview; do not assume placeholders are requirements.

## Who this is for

_Not established yet._

## Situation today

- **Trigger or context:** Not established.
- **What people do now (including workarounds or doing nothing):** Not established.
- **Where that approach falls short:** Not established.
- **Evidence versus assumptions:** No evidence recorded yet.

## Desired outcome

_What should become possible or better for these people? Not established yet._

## Why this is worth pursuing

_User value, possible business value, and reasons to act now, if known. Not established._

## Product boundaries

- **Must preserve or satisfy:** Not established.
- **Non-goals:** Not established.
- **Important constraints (time, cost, legal, operational, access):** Not established.

## Core product concepts and journeys

_People, objects, actions, states, and relationships that should remain coherent across features. Not established._

## How we will judge success

_Observable user results, quality floors, and useful signals. Do not invent targets or treat intentions as measured results._

## Important unknowns and decisions

- Open: Which problem and outcome should become the accepted product boundary?
- Open: What evidence or direct observation could change that decision?

## Accepted direction

**None yet.** The product owner must explicitly approve material changes to this section and to accepted purpose, scope, or behavior.
